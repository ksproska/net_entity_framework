﻿// 2.  Stwórz zmienną o nazwie class, zapis do niej jakąś wartość i wypisz na ekranie.

using System;

namespace L06_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int @class = 10;
            Console.WriteLine(@class);
        }
    }
}
